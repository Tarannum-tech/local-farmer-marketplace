// script.js

let cartCount = 0;

function addToCart(productName) {
  cartCount++;
  document.getElementById('cart-count').innerText = cartCount;
  alert(`${productName} added to cart!`);
}


// login-validation.js

function validateLoginForm() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  if (username === "" || password === "") {
    alert("Please enter both username and password.");
    return false;
  }

  // Optional: Simulate login
  alert("Login successful!");
  return true;
}
// login-validation.js

function validateLoginForm() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  if (username === "" || password === "") {
    alert("Please enter both username and password.");
    return false;
  }

  // Optional: Simulate login
  alert("Login successful!");
  return true;
}
<form class="auth-form" onsubmit="return validateLoginForm()">
  <input type="text" id="username" placeholder="Username" />
  <input type="password" id="password" placeholder="Password" />
  <button type="submit">Login</button>
</form>
// contact-validation.js

function validateContactForm() {
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  if (name === "" || email === "" || message === "") {
    alert("Please fill in all fields.");
    return false;
  }

  alert("Thanks for contacting us!");
  return true;
}
<form class="auth-form" onsubmit="return validateContactForm()">
  <input type="text" id="name" placeholder="Your Name" />
  <input type="email" id="email" placeholder="Your Email" />
  <textarea id="message" rows="4" placeholder="Your Message"></textarea>
  <button type="submit">Send</button>
</form>
  function addToCart(item) {
      alert(item + " added to cart!");
      // You can update cart count logic here too
    }